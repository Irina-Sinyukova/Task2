class Fish:
    def __init__(self, title, climat, price, life, count_fish, meal):
        self.title = title
        self.climat = climat
        self.price = price
        self.life = life
        self.count_fish = count_fish
        self.meal = meal

    # Перекрытие функции Print
    def __str__(self):
        return f"{self.title} {self.climat} {self.price} {self.life} {self.count_fish} {self.meal}"

    # Операции сравнения
    def __lt__(self, other):  # <
        self_price, other_price = (self.price, other.price)
        return self_price < other_price

    def __eq__(self, other):  # ==
        self_price, other_price = (self.price, other.price)
        return self_price == other_price

    def __le__(self, other):  # <=
        if self.__eq__(other):
            return True

        if self.__lt__(other):
            return True
        else:
            return False

    def increase_count_fish(self, count):
        self.count_fish += count


class Aquarium:
    def __init__(self, volume, shape, cleaning_date, f, count_fish):
        self.volume = volume
        self.shape = shape
        self.cleaning_date = cleaning_date
        self.f = f
        self.count_fish = count_fish

    # Перекрытие функции Print
    def __str__(self):
        return f"{self.f.title} {self.volume} {self.shape} {self.cleaning_date} {self.count_fish}"

    # Операции сравнения
    def __lt__(self, other):  # <
        self_count_fish, other_count_fish = (self.count_fish, other.count_fish)
        return self_count_fish < other_count_fish

    def __eq__(self, other):  # ==
        self_count_fish, other_count_fish = (self.count_fish, other.count_fish)
        return self_count_fish == other_count_fish

    def __le__(self, other):  # <=
        if self.__eq__(other):
            return True

        if self.__lt__(other):
            return True
        else:
            return False


fish1 = Fish('Золотая рыбка', '18-23°C', '282', '10 лет', 50, 'всеядные')
fish2 = Fish('Данио', '17-25°C', '730', '3-4 года', 70, 'растительноядные')
aquarium1 = Aquarium(fish1, '200', 'Круглый', '12-03-2022', 50)
aquarium2 = Aquarium(fish2, '350', 'Прямоугольный', '13-11-2022', 70)

print('Сравнение рыб по цене:')
# Сравнение рыб по цене
print(fish1 > fish2)
print(fish1 < fish2)
print(fish1 == fish2)
print(fish1 >= fish2)
print(fish1 <= fish2)

print('Сравнение квариумов по количеству обитателей:')
# Сравнение аквариумов по количеству обитателей
print(aquarium1 > aquarium2)
print(aquarium1 < aquarium2)
print(aquarium1 == aquarium2)
print(aquarium1 >= aquarium2)
print(aquarium1 <= aquarium2)

fish1.increase_count_fish(0)
print(fish1)

# Вывод всех обитателей указанного аквариума
aquarium = input('Аквариум: ')
if aquarium == 'Круглый':
    print(fish1)
else:
    print(fish2)
